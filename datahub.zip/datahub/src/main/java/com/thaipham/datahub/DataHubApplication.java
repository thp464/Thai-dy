package com.thaipham.datahub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataHubApplication.class, args);
	}

}
